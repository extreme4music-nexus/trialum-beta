# Trialum public beta publication policy

## Separation of responsibilities

**Private `Trialum`**: active engineering, Living World phases, unfinished
features, tests, internal server infrastructure, internal workflows,
development artifacts and confidential records.

**Public `trialum-beta`**: only the exact beta-source snapshot explicitly
accepted by the owner. Its Git history must begin independently; never
mirror the private repository or publish its history.

The public repo may receive GitHub Actions test/build workflows that use
standard GitHub-hosted runners. Such workflows must not deploy to a live
server, sign release binaries or require access to private upstream content.

## Mandatory publishing gates

1. Owner explicitly approves the exact beta version and private source commit.
2. Reconcile first-party copyright, the private repository's existing MIT
   LICENSE, contributor rights and third-party components. Obtain legal
   review before changing licensing assumptions.
3. Construct a fresh, allowlisted source snapshot; do not copy `.git/`,
   development history, signing artifacts, internal logs or home-server configs.
4. Perform pre-publication secret scanning and manual security/privacy review
   on the exact snapshot, including Git LFS and binary files.
5. Confirm that tests and Android unsigned compilation pass, and confirm
   owner-device QA, restore compatibility, online/offline behavior and
   security/privacy acceptance.
6. Record the approved source commit, beta version, checks and owner approval
   in `.trialum-release.json` in the snapshot.
7. Publish one reviewed commit on the public repository after an independent
   human review of the final staged files; tag only owner-approved releases.
8. Publish no locally signed APK/AAB or release signing credentials to this
   repository unless the owner separately authorizes binary distribution.

**Android signing: local only.** Official package names, Play Console
credentials and release signing remain under owner control.

## No automatic mirroring

Merges into private `Trialum/main` must NEVER automatically push code into
`trialum-beta`. Every public publication requires a separate explicit owner
decision. A passing CI check is not an approval to publish.

Use `docs/PUBLICATION_CHECKLIST.md` for the full gate.
