#!/usr/bin/env python3
"""Conservative, advisory public repository hygiene gate. Not a secret-audit substitute."""
from pathlib import Path
import json
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
DISALLOWED_PARTS = {
    ".git", ".env", ".ssh", ".gradle", "node_modules",
    "__pycache__", ".venv", "backups", "private", "secrets",
}
DISALLOWED_SUFFIXES = {".jks", ".keystore", ".p12", ".pfx", ".pem", ".key", ".sqlite", ".db"}
DISALLOWED_NAMES = {"google-services.json", "service-account.json", "id_rsa",
                    "id_ed25519", "credentials.json", ".npmrc", ".pypirc"}
SOURCE_TOPLEVEL = {
    "android", "app", "server", "src", "web", "game", "model-packs",
    "gradle", "www", "public", "assets",
}
# Heuristics only: false positives and false negatives are expected.
TOKEN_PATTERNS = {
    "private key header": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "GitHub token": re.compile(r"\b(?:ghp|gho|ghu|ghs|ghr)_[A-Za-z0-9_]{25,}\b"),
    "GitHub fine-grained token": re.compile(r"\bgithub_pat_[A-Za-z0-9_]{30,}\b"),
    "AWS access key": re.compile(r"\b(?:AKIA|ASIA)[0-9A-Z]{16}\b"),
    "Google API key": re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b"),
}
errors = []
source_present = False

for path in ROOT.rglob("*"):
    if not path.is_file():
        continue
    rel = path.relative_to(ROOT)
    if any(part in DISALLOWED_PARTS or part.startswith(".env") for part in rel.parts):
        errors.append(f"BLOCKED PATH: {rel}")
        continue
    if path.suffix.lower() in DISALLOWED_SUFFIXES or path.name.lower() in DISALLOWED_NAMES:
        errors.append(f"BLOCKED FILE TYPE: {rel}")
        continue
    if rel.parts[0] in SOURCE_TOPLEVEL:
        source_present = True
    if path.stat().st_size > 5_000_000:
        # Not inherently dangerous, but binary/media require human review.
        errors.append(f"MANUAL REVIEW REQUIRED (large file): {rel}")
        continue
    try:
        content = path.read_text(encoding="utf-8")
    except (UnicodeDecodeError, OSError):
        # Binary files cannot be inspected by this heuristic scan.
        continue
    for name, pattern in TOKEN_PATTERNS.items():
        for match in pattern.finditer(content):
            line = content.count("\n", 0, match.start()) + 1
            errors.append(f"PATTERN {name}: {rel}:{line}")

required = ["README.md", "LICENSE", "RELEASE_POLICY.md", "SECURITY.md"]
for name in required:
    if not (ROOT / name).is_file():
        errors.append(f"MISSING REQUIRED FILE: {name}")

if source_present:
    manifest = ROOT / ".trialum-release.json"
    if not manifest.is_file():
        errors.append("SOURCE PRESENT WITHOUT .trialum-release.json")
    else:
        try:
            data = json.loads(manifest.read_text(encoding="utf-8"))
            if not re.fullmatch(r"[0-9a-f]{40}", str(data.get("source_commit", ""))):
                errors.append("INVALID MANIFEST: source_commit must be full hex SHA-1")
            if not re.fullmatch(r"\d+\.\d+(?:\.\d+)?-beta\.[0-9A-Za-z.-]+",
                                str(data.get("version", ""))):
                errors.append("INVALID MANIFEST: beta version required")
            for field in ("owner_approved", "license_review_complete",
                          "secret_scan_complete", "qa_acceptance_complete"):
                if data.get(field) is not True:
                    errors.append(f"INVALID MANIFEST: {field} must be true")
        except (OSError, ValueError) as exc:
            errors.append(f"INVALID MANIFEST JSON: {type(exc).__name__}")

print(f"Public repository gate: {'FAILED' if errors else 'PASS'}")
for error in errors:
    print(error)
if not errors:
    print("Basic checks passed. This is NOT a legal review, secret-scanning certification, "
          "QA acceptance, or permission to publish.")
sys.exit(1 if errors else 0)
