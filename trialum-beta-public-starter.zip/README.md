# Trialum — Public Beta Source

**ТРИАЛУМ — Жива искра** · Trialum — Living Spark

> **Source available, not open source.** Copyright © 2026 Toni Cvetkovski. All rights reserved.

## Македонски

Ова е **јавниот репозиториум за одобрени бета-изданија** на Trialum. Главниот развој, експериментите, приватните тестови и работните гранки остануваат во одделен приватен репозиториум.

**Во моментот овде нема објавен изворен код на бета-верзија.** Код ќе се додава само по експлицитно одобрение на сопственикот и по безбедносна, авторско-правна и техничка проверка.

Може да го разгледувате објавениот код и да поднесувате идеи или пријави за грешки. **Не се доделува дозвола** за повторно издавање, дистрибуирање, модифицирање, комерцијална употреба или создавање деривати на играта, освен ако сопственикот изречно не одобри во писмена форма или ако задолжителен закон одредува поинаку. GitHub дозволува преглед и fork во рамките на своите услови.

Развојните предлози се добредојдени преку Issues. Никој освен сопственикот не одлучува за официјални промени, спојување код, објавување или издавање.

## English

This repository is the **public distribution channel for owner-approved Trialum beta source snapshots**, not the development repository.

**No beta game source code is published here yet.** A snapshot will be published only after explicit owner approval and security, licensing, privacy, and technical review.

The source is available for inspection, but **it is not open-source licensed**. No permission is granted to repackage, modify, redistribute, commercialize, or create derivatives of Trialum except with the copyright owner's express written permission or as required by applicable law. Viewing and forking through GitHub are subject to GitHub's Terms of Service.

Suggestions and bug reports are welcome through Issues. Code contributions are not accepted automatically.

## Policy documents

- [LICENSE](LICENSE) — first-party copyright and source availability
- [TRADEMARKS.md](TRADEMARKS.md) — Trialum names and identity
- [CONTRIBUTING.md](CONTRIBUTING.md) — suggestions and contributions
- [SECURITY.md](SECURITY.md) — responsible vulnerability reporting
- [RELEASE_POLICY.md](RELEASE_POLICY.md) — approved beta publishing
- [docs/PUBLICATION_CHECKLIST.md](docs/PUBLICATION_CHECKLIST.md) — publication gate

**Release signing is exclusively local, controlled by the owner.** Public GitHub Actions may compile/test unsigned builds but must never hold or use release signing keys.

> Disclaimer: third-party components, when eventually included, retain their respective licenses. A public snapshot must not imply that the project owner owns third-party material.
