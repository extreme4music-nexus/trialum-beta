# Contributions and suggestions

The official Trialum codebase is owner-controlled. The public repository is
primarily an approved beta-source publication channel, not an open
collaboration or open-source development project.

## Welcome
- Report reproducible bugs via GitHub Issues.
- Suggest improvements, accessibility features, design ideas or translations.
- Keep all reports respectful; avoid personal data and secrets.

## Code contributions
Please **do not submit pull requests containing code or assets** without
prior explicit agreement with the owner. A submission is not automatically
accepted or merged. No direct write access is granted to outside developers.

Before any code is accepted, the contributor and project owner must agree
in writing about authorship, required licenses, reuse rights and any
compensation terms. No profit share or employment relationship arises
automatically from a suggestion or submission.

Only the project owner authorizes merges, beta publications, official
releases and use of the Trialum identity.

For security issues use SECURITY.md; do not open a public issue.
