# Security policy

Do not disclose vulnerabilities, credentials, keys, user data, or internal
infrastructure details in public Issues, Pull Requests or Actions logs.

Report potential vulnerabilities privately using GitHub's **Report a
vulnerability** / private vulnerability reporting feature if enabled.
If that channel is unavailable, open a public issue requesting a private
contact channel without revealing the vulnerability.

The public beta repository is not a production support contract. Public
publication occurs only after the owner authorizes an audited snapshot.

Never include Android release-signing keystores, passwords, credentials,
FCM service-account files, cloud API secrets, personal backups or private
deployment configuration in the repository.
