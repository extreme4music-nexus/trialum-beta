# Public beta publication checklist

Do NOT check any gate off based only on a generated script or automated green
CI result. The project owner gives the final approval.

- [ ] A real beta is finished and expressly approved by the owner.
- [ ] Source commit SHA and release version are fixed, not a moving branch.
- [ ] Existing MIT license in private `Trialum/LICENSE` is reviewed with legal
      counsel: confirm original authorship, prior grants, contributors and
      whether new terms may apply to the chosen snapshot.
- [ ] Every external library, model, soundtrack, font, image and asset is
      inventoried; attribution and distribution obligations are met.
- [ ] A fresh release tree is assembled without original `.git` history.
- [ ] All secrets are excluded (`.env`, `*.jks`, `*.keystore`, `*.pem`,
      OAuth credentials, API keys, service accounts, user backups).
- [ ] Home-server DDNS, private VPN settings, deploy scripts, IP addresses,
      host details and internal infrastructure docs are excluded or reviewed.
- [ ] Public snapshot is scanned for credential patterns and reviewed manually.
- [ ] No personal data or real testers' messages/files included.
- [ ] Security/privacy review covers invitations, accounts, playground
      synchronization, offline recovery and user-data deletion.
- [ ] Local backup and restore regression checks pass on supported versions.
- [ ] English + Macedonian UI and accessibility are tested.
- [ ] Unsigned Android build/test succeeds on the exact published source.
- [ ] Official application ID and Play app signing ownership remain unchanged.
- [ ] No signing, release certificates or Play publishing credentials in CI.
- [ ] `.trialum-release.json` records approved source SHA, beta version,
      and owner approval for the *exact* snapshot.
- [ ] A human inspects the final staged diff before the first public push.
- [ ] Approved tag is created only after public checks pass.
- [ ] Source / binaries / notes match the owner's publication decision.

## Suggested manifest for an approved beta

Create a `.trialum-release.json` file **only when source is being published**.
The gate script checks its basic fields, not the authenticity of approval.

```json
{
  "version": "1.6.0-beta.1",
  "source_commit": "0000000000000000000000000000000000000000",
  "owner_approved": true,
  "license_review_complete": true,
  "secret_scan_complete": true,
  "qa_acceptance_complete": true
}
```

Replace the example SHA with the actual private source commit. Do not use an
unverified release just because these fields are set to `true`.
