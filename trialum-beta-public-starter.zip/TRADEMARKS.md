# Trialum name, identity and branding

Trialum / Триалум, its official logos, distinctive character designs,
official artwork, narrative universe and presentation are associated with
the official game maintained by the rights holder.

No permission is granted to use those assets or identifiers to:
- claim to be the official game, publisher or development team;
- distribute unofficial applications under the same or confusingly similar branding;
- imply endorsement, sponsorship or official affiliation;
- reproduce protected art or character designs in an unauthorized derivative game.

Factual references to the game, commentary and other uses permitted by
applicable law are not prohibited by this policy. This document does not
claim a registered trademark where registration has not been verified.

Copyright © 2026 Toni Cvetkovski. All rights reserved.
